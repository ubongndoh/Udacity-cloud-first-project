This project is the first project is the cloud devops engineer program by udacity. 
Its involves the process or steps to take in order to host a static website on cloud using the AWS platform
The screenshots are part of the requirements of the project

The site can be access or tested  through the links below

https://dzy5291kpwwut.cloudfront.net

http://my-1st-udacity-website-bucket.s3-website-us-east-1.amazonaws.com/

http://my-1st-udacity-website-bucket.s3.amazonaws.com/index.html


Thank you for reviewing my first project. 
